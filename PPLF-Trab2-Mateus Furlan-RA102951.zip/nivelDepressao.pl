nivelDepressao("| Você apresenta pouca ou nenhuma depressão.                     |", 9).
nivelDepressao("| Você apresenta um nível de depressão baixíssimo.               |", 10).
nivelDepressao("| Você apresenta um nível de depressão baixíssimo.               |", 11).
nivelDepressao("| Você apresenta um nível de depressão baixíssimo.               |", 12).
nivelDepressao("| Você apresenta um nível de depressão baixíssimo.               |", 13).
nivelDepressao("| Você apresenta um nível de depressão baixo.                    |", 14).
nivelDepressao("| Você apresenta um nível de depressão baixo.                    |", 15).
nivelDepressao("| Você apresenta um nível de depressão baixo.                    |", 16).
nivelDepressao("| Você apresenta um nível de depressão baixo.                    |", 17).
nivelDepressao("| Você apresenta um nível de depressão baixo.                    |", 18).
nivelDepressao("| Você apresenta um nível de depressão moderado.                 |", 19).
nivelDepressao("| Você apresenta um nível de depressão moderado.                 |", 20).
nivelDepressao("| Você apresenta um nível de depressão moderado.                 |", 21).
nivelDepressao("| Você apresenta um nível de depressão moderado.                 |", 22).
nivelDepressao("| Você apresenta um nível de depressão moderado.                 |", 23).
nivelDepressao("| Você apresenta um nível de depressão moderado ou alto.         |", 24).
nivelDepressao("| Você apresenta um nível de depressão moderado ou alto.         |", 25).
nivelDepressao("| Você apresenta um nível de depressão moderado ou alto.         |", 26).
nivelDepressao("| Você apresenta um nível de depressão moderado ou alto.         |", 27).
nivelDepressao("| Você apresenta um nível de depressão moderado ou alto.         |", 28).
nivelDepressao("| Você apresenta um nível de depressão moderado ou alto.         |", 29).
nivelDepressao("| Você apresenta um nível de depressão alto.                     |", 30).
nivelDepressao("| Você apresenta um nível de depressão alto.                     |", 31).
nivelDepressao("| Você apresenta um nível de depressão alto.                     |", 32).
nivelDepressao("| Você apresenta um nível de depressão alto.                     |", 33).
nivelDepressao("| Você apresenta um nível de depressão alto.                     |", 34).
nivelDepressao("| Você apresenta um nível de depressão alto.                     |", 35).
nivelDepressao("| Você apresenta um nível de depressão alto.                     |", 36).

