nivelEstresse("| Você apresenta pouca ou nenhuma indicação de estresse.         |", 8).
nivelEstresse("| Você apresenta pouca ou nenhuma indicação de estresse.         |", 9).
nivelEstresse("| Você apresenta pouca ou nenhuma indicação de estresse.         |", 10).
nivelEstresse("| Você apresenta pouca ou nenhuma indicação de estresse.         |", 11).
nivelEstresse("| Você apresenta pouca ou nenhuma indicação de estresse.         |", 12).
nivelEstresse("| Você apresenta pouca ou nenhuma indicação de estresse.         |", 13).
nivelEstresse("| Você apresenta pouca ou nenhuma indicação de estresse.         |", 14).
nivelEstresse("| Você apresenta pouca ou nenhuma indicação de estresse.         |", 15).
nivelEstresse("| Você apresenta pouca ou nenhuma indicação de estresse.         |", 16).
nivelEstresse("| Você apresenta pouca ou nenhuma indicação de estresse.         |", 17).
nivelEstresse("| Você apresenta um nível de estresse baixo.                     |", 18).
nivelEstresse("| Você apresenta um nível de estresse baixo.                     |", 19).
nivelEstresse("| Você apresenta um nível de estresse baixo.                     |", 20).
nivelEstresse("| Você apresenta um nível de estresse baixo.                     |", 21).
nivelEstresse("| Você apresenta um nível de estresse baixo.                     |", 22).
nivelEstresse("| Você apresenta um nível de estresse baixo.                     |", 23).
nivelEstresse("| Você apresenta um nível de estresse baixo.                     |", 24).
nivelEstresse("| Você apresenta um nível de estresse baixo.                     |", 25).
nivelEstresse("| Você apresenta um nível de estresse baixo.                     |", 26).
nivelEstresse("| Você apresenta um nível de estresse moderado.                  |", 27).
nivelEstresse("| Você apresenta um nível de estresse moderado.                  |", 28).
nivelEstresse("| Você apresenta um nível de estresse moderado.                  |", 29).
nivelEstresse("| Você apresenta um nível de estresse moderado.                  |", 30).
nivelEstresse("| Você apresenta um nível de estresse moderado.                  |", 31).
nivelEstresse("| Você apresenta um nível de estresse moderado.                  |", 32).
nivelEstresse("| Você apresenta um nível de estresse moderado.                  |", 33).
nivelEstresse("| Você apresenta um nível de estresse moderado.                  |", 34).
nivelEstresse("| Você apresenta um nível de estresse moderado.                  |", 35).
nivelEstresse("| Você apresenta um nível de estresse alto.                      |", 36).
nivelEstresse("| Você apresenta um nível de estresse alto.                      |", 37).
nivelEstresse("| Você apresenta um nível de estresse alto.                      |", 38).
nivelEstresse("| Você apresenta um nível de estresse alto.                      |", 39).
nivelEstresse("| Você apresenta um nível de estresse alto.                      |", 40).