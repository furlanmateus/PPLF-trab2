nivelAnsiedade("| Você apresenta pouca ou nenhuma ansiedade.                     |", 7).
nivelAnsiedade("| Você apresenta pouca ou nenhuma ansiedade.                     |", 8).
nivelAnsiedade("| Você apresenta pouca ou nenhuma ansiedade.                     |", 9).
nivelAnsiedade("| Você apresenta pouca ou nenhuma ansiedade.                     |", 10).
nivelAnsiedade("| Você apresenta pouca ou nenhuma ansiedade.                     |", 11).
nivelAnsiedade("| Você apresenta pouca ou nenhuma ansiedade.                     |", 12).
nivelAnsiedade("| Você apresenta pouca ou nenhuma ansiedade.                     |", 13).
nivelAnsiedade("| Você apresenta um nível baixo de ansiedade.                    |", 14).
nivelAnsiedade("| Você apresenta um nível baixo de ansiedade.                    |", 15).
nivelAnsiedade("| Você apresenta um nível baixo de ansiedade.                    |", 16).
nivelAnsiedade("| Você apresenta um nível baixo de ansiedade.                    |", 17).
nivelAnsiedade("| Você apresenta um nível baixo de ansiedade.                    |", 18).
nivelAnsiedade("| Você apresenta um nível baixo de ansiedade.                    |", 19).
nivelAnsiedade("| Você apresenta um nível baixo de ansiedade.                    |", 20).
nivelAnsiedade("| Você apresenta um nível moderado de ansiedade.                 |", 21).
nivelAnsiedade("| Você apresenta um nível moderado de ansiedade.                 |", 22).
nivelAnsiedade("| Você apresenta um nível moderado de ansiedade.                 |", 23).
nivelAnsiedade("| Você apresenta um nível moderado de ansiedade.                 |", 24).
nivelAnsiedade("| Você apresenta um nível moderado de ansiedade.                 |", 25).
nivelAnsiedade("| Você apresenta um nível moderado de ansiedade.                 |", 26).
nivelAnsiedade("| Você apresenta um nível moderado de ansiedade.                 |", 27).
nivelAnsiedade("| Você apresenta um nível alto de ansiedade.                     |", 28).
nivelAnsiedade("| Você apresenta um nível alto de ansiedade.                     |", 29).
nivelAnsiedade("| Você apresenta um nível alto de ansiedade.                     |", 30).
nivelAnsiedade("| Você apresenta um nível alto de ansiedade.                     |", 31).
nivelAnsiedade("| Você apresenta um nível alto de ansiedade.                     |", 32).
nivelAnsiedade("| Você apresenta um nível alto de ansiedade.                     |", 33).
nivelAnsiedade("| Você apresenta um nível alto de ansiedade.                     |", 34).
nivelAnsiedade("| Você apresenta um nível alto de ansiedade.                     |", 35).
